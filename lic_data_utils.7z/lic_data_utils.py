import pdfplumber
import re

def extract_text(file,category):
    final = []
    pdf_fname = file
    # open the pdf
    pdf = pdfplumber.open(pdf_fname)
    page = pdf.pages
    for i,j in enumerate(page):
        table = page[i].extract_table()
        if (len(table[0]) == 8):
            out = extract_type1(table,category)
            final.append(out)
        else:
            out = extract_type2(page[i],table,category)
            final.append(out)
    return final

def extract_type1(table,category):
    out = []
    for i in range(1,len(table)):
        output = {}
        output['Name'] = table[i][0].split('\n')[-1]
        output['Policy_number'] = table[i][0].split('\n')[0]
        output['Premium_amount'] = table[i][4]
        output['Payment_date'] = table[i][6]
        output['frequency'] = table[i][3].split('\n')[-1]
        output['Type'] = category
        out.append(output)

    return out

def extract_type2(page,table,category):
    date_check = ('Date')
    regex = (r'\d{2}\/\d{2}\/\d{4}')
    out = []
    out1 = []
    text = page.extract_text()
    text = text.split('\n')
    for i in text:
        if i.startswith(date_check):
            output1 = {}
            find_date = re.search(regex,i)
            date = find_date.group(0)
            output1['payment_date'] = date
            out1.append(output1)
    for i in range(1,len(table)-4):
        output = {}
        output['Name'] = table[i][0].split('\n')[1]
        output['Policy_number'] = table[i][0].split('\n')[0]
        output['Premium_amount'] = table[i][2].split('\n')[0]
        output['frequency'] = table[i][2].split('\n')[1]
        out.append(output)
        
    for i in out1:
        out.append(i)
    return out